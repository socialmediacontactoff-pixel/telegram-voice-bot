# 🎙️ Bot Vocal Telegram

Bot Telegram qui convertit du texte en message vocal avec sons d'ambiance.

## Variables d'environnement (Railway)

| Variable | Description |
|---|---|
| `TELEGRAM_BOT_TOKEN` | Token obtenu via @BotFather |
| `ELEVENLABS_API_KEY` | Clé API ElevenLabs |
| `ADMIN_TELEGRAM_ID` | Votre Telegram ID (obtenez-le avec /myid) |

## Sons disponibles

Insérez ces balises n'importe où dans votre message :

| Balise | Effet |
|---|---|
| `/toux` | Toux |
| `/baillement` | Bâillement |
| `/rire` | Rire |
| `/soupir` | Soupir |
| `/hmm` | Hésitation |
| `/pause` | Silence court |

**Exemple :** `coucou ! /toux c'est Julia, tu vas bien ?`

## Commandes admin

| Commande | Action |
|---|---|
| `/adduser <id>` | Ajouter un abonné |
| `/removeuser <id>` | Supprimer un abonné |
| `/listusers` | Lister les abonnés |
| `/myid` | Voir son propre Telegram ID |

## Ajouter de vrais sons

Remplacez les fichiers dans `sounds/` par vos propres `.mp3` :
- `toux.mp3`
- `baillement.mp3`
- `rire.mp3`
- `soupir.mp3`
- `hmm.mp3`
- `pause.mp3`

## Déploiement Railway

1. Créez un repo GitHub avec ces fichiers
2. Connectez Railway à votre repo
3. Ajoutez les variables d'environnement
4. Deploy !
