"""
Script utilitaire pour générer des sons de remplacement (silence)
en attendant les vrais fichiers .mp3.
Lance ce script UNE SEULE FOIS pour créer le dossier sounds/.
"""
from pydub import AudioSegment
from pydub.generators import Sine
import os

SOUNDS_DIR = os.path.join(os.path.dirname(__file__), "sounds")
os.makedirs(SOUNDS_DIR, exist_ok=True)

sounds = {
    "toux.mp3":       500,   # 0.5s
    "baillement.mp3": 1500,  # 1.5s
    "rire.mp3":       800,
    "soupir.mp3":     1000,
    "hmm.mp3":        600,
    "pause.mp3":      500,
}

for filename, duration_ms in sounds.items():
    path = os.path.join(SOUNDS_DIR, filename)
    if not os.path.exists(path):
        silence = AudioSegment.silent(duration=duration_ms)
        silence.export(path, format="mp3")
        print(f"✅ Créé : {filename}")
    else:
        print(f"⏭️  Existe déjà : {filename}")

print("\nDossier sounds/ prêt.")
print("Remplacez les fichiers par de vrais sons pour un effet réaliste !")
